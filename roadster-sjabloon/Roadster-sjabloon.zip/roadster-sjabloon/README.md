# Roadster sjabloon

Dossier-sjabloon in de stijl van het Tesla Roadster-dossier: cover met grote foto en kerncijfers, inhoudsopgave, genummerde secties, labels (OFFICIEEL, BEVESTIGD, CLAIM, VOLGENS MEDIA, SCHATTING, ONBEVESTIGD), tabellen, citaten, kaders, tijdlijn, video's en genummerde bronnen. Op elke pagina staat een voettekst met paginanummer.

## Nieuw dossier in 3 stappen
1. `cp sjabloon.nl.json mijn-dossier.json` (Engels: `sjabloon.en.json`)
2. Vervang alle `[PLAATSHOUDERS]` door je eigen inhoud. Zet foto's in `afbeeldingen/`.
3. `python3 maak_dossier.py mijn-dossier.json` → PDF in `uitvoer/`
   (met `--html` krijg je alleen de HTML)

## Opmaak in teksten
- Label: `[[label:off]]`, `conf`, `claim`, `rep`, `est`, `unv`. Eigen labels voeg je toe in `"labels"`.
- Voetnoot: `[[bron:id]]` of `[[bron:id1,id2]]`. Bronnen staan in `"bronnen"` en worden automatisch genummerd. Een onbekende id geeft een foutmelding.
- Vet: `**tekst**`. Link: `[tekst](https://...)`. Nieuwe titelregel op de cover: `<br>`.

## Bloktypes
`p`, `lead`, `h3`, `lijst`, `tabel`, `kader` (stijl info/warn/dark), `citaat`, `figuur`, `figuren`, `tijdlijn`, `videos`, `legenda`, `twee_kolommen`, `pagina_einde`.
Voorbeelden van elk type staan in `handleiding.json` en in `uitvoer/Roadster-sjabloon-handleiding.pdf`.

## Instellingen
`taal` (nl/en), `bestandsnaam`, `voettekst`, `website`, `accentkleur` (standaard #c8102e). De stijl staat in `style.css`.

## Nodig
Python 3, Google Chrome/Chromium en de lettertypes Inter en Barlow. Pillow is alleen nodig om nieuwe grijze plaatshouders te maken.

## Let op
Kaders en tabelrijen worden niet gesplitst. Een lang kader kan daardoor naar de volgende pagina springen. Elke sectie begint op een nieuwe pagina. Controleer de PDF altijd pagina voor pagina.
