#!/usr/bin/env python3
"""Roadster sjabloon – generator. Gebruik:  python3 maak_dossier.py inhoud.json [--html]
Leest één JSON-inhoudsbestand en maakt uitvoer/<bestandsnaam>.pdf (via headless Chrome)."""
import json, sys, os, re, html, subprocess, shutil

HERE = os.path.dirname(os.path.abspath(__file__))
UI = {
 'nl': {'contents':'Inhoud','sources':'Bronnen','accessed':'Alle bronnen zijn klikbaar.','labels':'Labels in dit dossier','cover_photo':'Coverfoto','compiled':'Samengesteld voor'},
 'en': {'contents':'Contents','sources':'Sources','accessed':'All sources are clickable.','labels':'Labels used in this dossier','cover_photo':'Cover photo','compiled':'Compiled for'},
}
DEFAULT_LABELS = {
 'nl': {'off':['t-off','OFFICIEEL','officiële bron (fabrikant, overheid)'],'conf':['t-conf','BEVESTIGD','door meerdere onafhankelijke bronnen bevestigd'],
        'claim':['t-claim','CLAIM','alleen een bewering van één persoon/partij'],'rep':['t-rep','VOLGENS MEDIA','gemeld door media, niet officieel'],
        'est':['t-est','SCHATTING','schatting of berekening'],'unv':['t-unv','ONBEVESTIGD','onbevestigd of tegenstrijdig']},
 'en': {'off':['t-off','OFFICIAL','official source (manufacturer, government)'],'conf':['t-conf','CONFIRMED','confirmed by several independent sources'],
        'claim':['t-claim','CLAIM','claim by a single person/party only'],'rep':['t-rep','PER MEDIA','reported by media, not official'],
        'est':['t-est','ESTIMATE','estimate or calculation'],'unv':['t-unv','UNCONFIRMED','unconfirmed or conflicting']},
}

def main():
    args=[a for a in sys.argv[1:] if not a.startswith('--')]
    if not args: sys.exit(__doc__)
    path=args[0]; C=json.load(open(path, encoding='utf-8'))
    lang=C.get('taal', C.get('lang','nl')); ui=UI[lang]
    labels={k:list(v) for k,v in DEFAULT_LABELS[lang].items()}
    for k,v in C.get('labels',{}).items(): labels[k]=[v.get('klasse',labels.get(k,['t-unv'])[0]), v['tekst'], v.get('uitleg','')]
    src=C.get('bronnen',[]); IDX={s['id']:i+1 for i,s in enumerate(src)}; URL={s['id']:s['url'] for s in src}
    base=os.path.dirname(os.path.abspath(path))
    def img(p): return 'file://'+(p if os.path.isabs(p) else os.path.join(base,p))
    def inline(t):
        t=str(t); keep=[]
        def stash(m): keep.append(m.group(0)); return f'\x00{len(keep)-1}\x00'
        t=re.sub(r'<(code|pre)\b.*?</\1>',stash,t,flags=re.S)   # code/pre niet verwerken
        def lab(m):
            k=m.group(1)
            if k not in labels: raise SystemExit(f'Onbekend label [[label:{k}]]; bekend: {", ".join(labels)}')
            c,txt,_=labels[k]; return f'<span class="tag {c}">{html.escape(txt)}</span>'
        def ref(m):
            ks=[k.strip() for k in m.group(1).split(',')]
            for k in ks:
                if k not in IDX: raise SystemExit(f'Onbekende bron-id in [[bron:{k}]]')
            return '<sup>'+','.join(f'<a href="{URL[k]}">{IDX[k]}</a>' for k in ks)+'</sup>'
        def link(m): return f'<a href="{m.group(2)}">{m.group(1)}</a>'
        t=re.sub(r'\[\[label:(\w+)\]\]',lab,t); t=re.sub(r'\[\[bron:([\w, -]+)\]\]',ref,t)
        t=re.sub(r'\[([^\]]+)\]\((https?://[^)]+)\)',link,t)
        t=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',t)
        return re.sub(r'\x00(\d+)\x00',lambda m: keep[int(m.group(1))],t)
    def block(b):
        T=b['type']
        if T=='p': return f'<p class="{b.get("klasse","")}">{inline(b["tekst"])}</p>'
        if T=='lead': return f'<p class="lead">{inline(b["tekst"])}</p>'
        if T=='h3': return f'<h3>{inline(b["tekst"])}</h3>'
        if T=='lijst': return '<ul>'+''.join(f'<li>{inline(x)}</li>' for x in b['items'])+'</ul>'
        if T=='tabel':
            h=''.join(f'<th>{inline(x)}</th>' for x in b['kop'])
            r=''.join('<tr>'+''.join(f'<td>{inline(c)}</td>' for c in row)+'</tr>' for row in b['rijen'])
            return f'<table><thead><tr>{h}</tr></thead><tbody>{r}</tbody></table>'
        if T=='kader': return f'<div class="box {b.get("stijl","info")}"><h4>{inline(b.get("titel",""))}</h4>{inline(b["tekst"])}</div>'
        if T=='citaat': return f'<div class="quote">“{inline(b["tekst"])}”<div class="who">{inline(b.get("wie",""))}</div></div>'
        if T=='figuur': return f'<figure><img src="{img(b["afbeelding"])}"><figcaption>{inline(b.get("onderschrift",""))}</figcaption></figure>'
        if T=='figuren':
            n=len(b['items']); cls='grid3' if n>=3 else 'grid2'
            return f'<div class="{cls}">'+''.join(block({'type':'figuur',**x}) for x in b['items'])+'</div>'
        if T=='tijdlijn': return '<div class="timeline">'+''.join(f'<div class="tl{" hot" if x.get("highlight") else ""}"><div class="d">{inline(x["datum"])}</div><div class="x">{inline(x["tekst"])}</div></div>' for x in b['items'])+'</div>'
        if T=='videos': return ''.join(f'<div class="vid"><img src="{img(x["afbeelding"])}"><div><div class="t"><a href="{x["url"]}">{inline(x["titel"])}</a></div><div class="m">{inline(x.get("meta",""))}</div><div class="u"><a href="{x["url"]}">{x["url"]}</a></div></div></div>' for x in b['items'])
        if T=='legenda': return f'<div class="box info"><h4>{ui["labels"]}</h4><div class="legend">'+' &nbsp; '.join(f'<span class="tag {c}">{html.escape(t)}</span> {html.escape(u)}' for c,t,u in labels.values())+'</div></div>'
        if T=='twee_kolommen': return '<div class="grid2" style="align-items:start">'+''.join('<div>'+''.join(block(x) for x in col)+'</div>' for col in b['kolommen'])+'</div>'
        if T=='pagina_einde': return '<div style="break-after:page"></div>'
        raise SystemExit(f'Onbekend bloktype: {T}')
    out=[]; A=out.append
    footer=C.get('voettekst', C['titel'].replace('<br>',' ')+' · Dossier')
    A(f'<!doctype html><html lang="{lang}"><head><meta charset="utf-8"><title>{html.escape(footer)}</title><link rel="stylesheet" href="file://{HERE}/style.css">'
      f'<style>@page {{ @bottom-left {{ content: "{footer.replace(chr(34),"")}"; }} }}'+(f' :root{{}} a,h2 .num,.kicker,.toc .n,.tl .d{{color:{C["accentkleur"]}}} .cover .stat,.quote{{border-color:{C["accentkleur"]}}}' if C.get('accentkleur') else '')+'</style></head><body>')
    cv=C['cover']
    stats=''.join(f'<div class="stat"><b>{inline(s["waarde"])}</b>{inline(s["label"])}</div>' for s in cv.get('kerncijfers',[]))
    A(f'''<div class="cover"><img class="bg" src="{img(cv["afbeelding"])}"><div class="shade"></div>
<div class="top"><div class="kicker">{inline(cv.get("kicker",""))}</div><h1>{cv["titel"]}</h1><div class="sub">{inline(cv.get("ondertitel",""))}</div></div>
<div class="bottom"><div class="stats">{stats}</div><div>{inline(cv.get("voetregel",""))}</div><div class="credit">{inline(cv.get("fotocredit",""))}</div></div></div>''')
    secs=C['secties']; titles=[C.get('samenvatting',{}).get('titel',ui['contents'])]+[s['titel'] for s in secs]+[ui['sources']]
    sm=C.get('samenvatting',{})
    A(f'<div id="s1"><div class="kicker">{ui["contents"]}</div><h2>{inline(titles[0])}</h2>')
    A('<div class="toc">'+''.join(f'<div><a href="#s{i}"><span class="n">{i:02d}</span>{inline(t)}</a></div>' for i,t in enumerate(titles,1))+'</div>')
    if sm.get('kerncijfers'): A('<div class="keyfacts">'+''.join(f'<div class="kf"><b>{inline(k["waarde"])}</b><span>{inline(k["label"])}</span></div>' for k in sm['kerncijfers'])+'</div>')
    for b in sm.get('blokken',[]): A(block(b))
    A('</div>')
    for i,s in enumerate(secs,2):
        A(f'<div class="section" id="s{i}"><div class="kicker">{i:02d}</div><h2><span class="num">{i:02d}</span>{inline(s["titel"])}</h2>')
        for b in s.get('blokken',[]): A(block(b))
        A('</div>')
    n=len(secs)+2
    A(f'<div class="section" id="s{n}"><div class="kicker">{n:02d}</div><h2><span class="num">{n:02d}</span>{ui["sources"]}</h2>')
    A(f'<p class="small">{inline(C.get("bronnen_intro",ui["accessed"]))}</p><div class="sources cols2"><ol>'+''.join(f'<li>{html.escape(x["titel"])}<br><a href="{x["url"]}">{html.escape(x["url"] if len(x["url"])<90 else x["url"][:87]+"…")}</a></li>' for x in src)+'</ol></div>')
    if C.get('website'): A(f'<div class="footer-link"><a href="{C["website"]["url"]}">{html.escape(C["website"]["tekst"])}</a></div>')
    A('</div></body></html>')
    name=C.get('bestandsnaam', os.path.splitext(os.path.basename(path))[0])
    od=os.path.join(HERE,'uitvoer'); os.makedirs(od,exist_ok=True)
    hp=os.path.join(od,name+'.html'); open(hp,'w',encoding='utf-8').write('\n'.join(out))
    if '--html' in sys.argv: print(hp); return
    chrome=shutil.which('google-chrome') or shutil.which('chromium') or shutil.which('chromium-browser')
    if not chrome: sys.exit('Chrome/Chromium niet gevonden; HTML staat in '+hp)
    pp=os.path.join(od,name+'.pdf')
    subprocess.run([chrome,'--headless=new','--no-sandbox','--disable-gpu','--no-pdf-header-footer','--allow-file-access-from-files',f'--print-to-pdf={pp}','file://'+hp],check=True,stderr=subprocess.DEVNULL)
    print(pp)
if __name__=='__main__': main()
