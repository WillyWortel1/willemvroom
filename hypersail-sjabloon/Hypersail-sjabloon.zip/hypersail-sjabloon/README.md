# Hypersail sjabloon

Gids-sjabloon in een editoriale stijl: serif (Newsreader) met Inter voor labels, inkt #0C0C0B op papier #F3F1EC en een gouden accent #B8963E. Cover met groot beeld en kerncijfers, inhoudsopgave, genummerde hoofdstukken, labels (OFFICIEEL, BEVESTIGD, CLAIM, VOLGENS MEDIA, SCHATTING, ONBEVESTIGD), tabellen, citaten, kaders, tijdlijn, video's en genummerde bronnen. Op elke pagina staat een voettekst met paginanummer. Het sjabloon bevat alleen neutrale plaatshouders.

## Nieuwe gids in 3 stappen
1. `cp sjabloon.nl.json mijn-gids.json` (Engels: `sjabloon.en.json`)
2. Vervang alle `[PLAATSHOUDERS]` door je eigen inhoud. Zet je beelden in `afbeeldingen/`.
3. `python3 maak_gids.py mijn-gids.json` → PDF in `uitvoer/`
   (met `--html` krijg je alleen de HTML)

## Opmaak in teksten
- Label: `[[label:off]]`, `conf`, `claim`, `rep`, `est`, `unv`. Eigen labels voeg je toe in `"labels"`.
- Voetnoot: `[[bron:id]]` of `[[bron:id1,id2]]`. Bronnen staan in `"bronnen"` en worden automatisch genummerd. Een onbekende id geeft een foutmelding.
- Vet: `**tekst**`. Link: `[tekst](https://...)`. Nieuwe titelregel op de cover: `<br>`; cursief (goud op de cover): `<i>…</i>`.
- Per hoofdstuk kun je een eigen bovenregel zetten met `"kicker"` (standaard ‘Hoofdstuk’ / ‘Chapter’).

## Bloktypes
`p`, `lead`, `h3`, `lijst`, `tabel`, `kader` (stijl info/warn/dark), `citaat`, `figuur`, `figuren`, `tijdlijn`, `videos`, `legenda`, `twee_kolommen`, `pagina_einde`.
Voorbeelden van elk type staan in `handleiding.json` en in `uitvoer/Hypersail-sjabloon-handleiding.pdf`.

## Instellingen
`taal` (nl/en), `bestandsnaam`, `voettekst`, `website`, `accentkleur` (standaard #B8963E). De stijl staat in `style.css`.

## Nodig
Python 3 en Google Chrome/Chromium. De lettertypes zitten in `fonts/` (Newsreader en Inter, beide onder de SIL Open Font License 1.1; zie `fonts/OFL-*.txt`). Pillow is alleen nodig als je nieuwe plaatshouders wilt maken.

## Let op
Kaders en tabelrijen worden niet gesplitst. Een lang kader kan daardoor naar de volgende pagina springen. Elk hoofdstuk begint op een nieuwe pagina. Controleer de PDF altijd pagina voor pagina.
